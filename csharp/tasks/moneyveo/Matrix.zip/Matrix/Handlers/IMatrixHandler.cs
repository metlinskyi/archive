﻿namespace Matrix.Handlers
{
    public interface IMatrixHandler
    {
        Matrix For(Matrix matrix);
    }
}
